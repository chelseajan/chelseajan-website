import React from 'react';


const aboutMe = (props) => {
 return (
    <div>test</div>
   )
}   

export default aboutMe

