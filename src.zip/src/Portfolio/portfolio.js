import React from 'react';
import Title from '../Title/title';
import Project from '../Portfolio/project'
import { hiddenfish } from '../media/hiddenfish.jpg'

const portfolio = (props) => {

    const experiences = [
        {
            projectName: "Animal Crossing New Horizons",
            projectType:"Game Development",
            href: ""
        },
        {
            src: { hiddenfish },
            projectName: "Hidden Fish Website Re-Design",
            projectType:"Restaurant Website",
            href: ""
        },
        {
            projectName: "Test project name",
            projectType:"Test project type",
            href: ""
        },
        {
            projectName: "Test project name",
            projectType:"Test project type",
            href: ""
        },
        {
            projectName: "Test project name",
            projectType:"Test project type",
            href: ""
        },
        {
            projectName: "Test project name",
            projectType:"Test project type",
            href: ""
        },
    ];
    return (
        <div className="portfolio background-layer">
            <div className="container section">
                <Title id="Portfolio" title="Portfolio." />

                <div className="grid">
                    {
                        experiences.map( obj => {
                            return (
                            <Project projectName={obj.projectName} projectType={obj.projectType} src={obj.src} />)
                        })
                    }

                </div>     
            </div>
        </div>
   )
}   


export default portfolio

