import React from 'react';
import '../App.css';

const footer = (props) => {
   
    return (
        <footer>
            <div className="container">
                <h4>Need a hand?</h4>
                        <p className="copyright">Designed &amp; Developed by Chelsea Jan 2020</p>   

            </div>
        </footer>

    )}

export default footer